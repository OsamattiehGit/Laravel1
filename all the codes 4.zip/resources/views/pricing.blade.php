@extends('layouts.app')

@section('title', 'Our Pricing')

@push('styles')
<style>
.pricing-hero {
    background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
    color: white;
    padding: 80px 0;
    text-align: center;
}

.pricing-title {
    font-size: 3rem;
    font-weight: bold;
    margin-bottom: 2rem;
}

.pricing-title .orange {
    color: #f97316;
}

.pricing-cards {
    display: flex;
    justify-content: center;
    gap: 2rem;
    padding: 60px 20px;
    flex-wrap: wrap;
    background: #f8fafc;
}

.pricing-card {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    width: 300px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    position: relative;
    transition: transform 0.3s ease;
}

.pricing-card:hover {
    transform: translateY(-10px);
}

.pricing-card.featured {
    transform: scale(1.05);
    border: 3px solid #f97316;
}

.plan-name {
    background: #f97316;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: bold;
    margin-bottom: 1rem;
    display: inline-block;
}

.plan-price {
    font-size: 2.5rem;
    font-weight: bold;
    color: #1e3a8a;
    margin-bottom: 0.5rem;
}

.plan-currency {
    font-size: 1.2rem;
    vertical-align: top;
}

.plan-period {
    color: #64748b;
    margin-bottom: 1rem;
}

.plan-features {
    list-style: none;
    padding: 0;
    margin: 2rem 0;
}

.plan-features li {
    padding: 0.5rem 0;
    color: #374151;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.feature-icon {
    width: 20px;
    height: 20px;
    background: #10b981;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 12px;
}

.choose-btn {
    background: #f97316;
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 10px;
    font-weight: bold;
    cursor: pointer;
    width: 100%;
    transition: background 0.3s ease;
}

.choose-btn:hover {
    background: #ea580c;
}

.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: white;
    margin: 15% auto;
    padding: 2rem;
    border-radius: 15px;
    width: 400px;
    text-align: center;
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

.modal-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
    margin-top: 1.5rem;
}

.btn-confirm {
    background: #10b981;
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    cursor: pointer;
}

.btn-cancel {
    background: #ef4444;
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    cursor: pointer;
}

.success-modal .modal-content {
    border-top: 5px solid #10b981;
}

.error-modal .modal-content {
    border-top: 5px solid #ef4444;
}

@media (max-width: 768px) {
    .pricing-cards {
        flex-direction: column;
        align-items: center;
    }

    .pricing-card.featured {
        transform: none;
    }
}
</style>
@endpush

@section('content')
<div class="pricing-hero">
    <div class="container">
        <h1 class="pricing-title">
            Our <span class="orange">Pricing</span>
        </h1>
    </div>
</div>

<div class="pricing-cards">
    @foreach($plans as $index => $plan)
    <div class="pricing-card {{ $index === 1 ? 'featured' : '' }}">
        <div class="plan-name">{{ $plan['name'] }}</div>
        <div class="plan-price">
            <span class="plan-currency">$</span>{{ number_format($plan['price'], 0) }}
        </div>
        <div class="plan-period">+ Tax</div>

        <ul class="plan-features">
            <li>
                <span class="feature-icon">✓</span>
                {{ $plan['limit'] }} Course{{ $plan['limit'] > 1 ? 's' : '' }} Access
            </li>
            <li>
                <span class="feature-icon">✓</span>
                Lifetime Access
            </li>
            <li>
                <span class="feature-icon">✓</span>
                Certificate of Completion
            </li>
        </ul>

        <button class="choose-btn" onclick="showConfirmModal('{{ $plan['id'] }}', '{{ $plan['name'] }}', {{ $plan['price'] }}, {{ $plan['limit'] }})">
            Choose Plan
        </button>
    </div>
    @endforeach
</div>

<!-- Modal for confirmation -->
<div id="confirmModal" class="modal">
    <div class="modal-content">
        <h3 id="modal-title">Confirm Subscription</h3>
        <p id="modal-message">Are you sure you want to subscribe to this plan?</p>
        <div class="modal-buttons">
            <button class="btn-confirm" onclick="confirmSubscription()">Yes, Subscribe</button>
            <button class="btn-cancel" onclick="closeModal()">Cancel</button>
        </div>
    </div>
</div>

<!-- Success/Error Modal -->
<div id="responseModal" class="modal">
    <div class="modal-content">
        <h3 id="response-title">Success!</h3>
        <p id="response-message"></p>
        <div class="modal-buttons">
            <button class="btn-confirm" onclick="closeResponseModal()">OK</button>
        </div>
    </div>
</div>

@push('scripts')
<script>
let selectedPlan = null;

function showConfirmModal(planId, planName, price, limit) {
    selectedPlan = { id: planId, name: planName, price: price, limit: limit };

    document.getElementById('modal-title').textContent = 'Confirm Subscription';
    document.getElementById('modal-message').innerHTML =
        `Are you sure you want to subscribe to <strong>${planName}</strong> for <strong>$${price}</strong>?<br>
        This will add <strong>${limit} course${limit > 1 ? 's' : ''}</strong> to your balance.`;

    document.getElementById('confirmModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('confirmModal').style.display = 'none';
    selectedPlan = null;
}

function closeResponseModal() {
    document.getElementById('responseModal').style.display = 'none';
    location.reload(); // Refresh to show updated balance
}

async function confirmSubscription() {
    if (!selectedPlan) return;

    try {
        const response = await fetch('{{ route("subscriptions.store") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                plan_id: selectedPlan.id
            })
        });

        const data = await response.json();

        closeModal();

        const responseModal = document.getElementById('responseModal');
        const responseTitle = document.getElementById('response-title');
        const responseMessage = document.getElementById('response-message');

        if (data.success) {
            responseModal.className = 'modal success-modal';
            responseTitle.textContent = 'Subscription Successful!';
            responseMessage.textContent = data.message;
        } else {
            responseModal.className = 'modal error-modal';
            responseTitle.textContent = 'Error';
            responseMessage.textContent = data.error || 'An error occurred. Please try again.';
        }

        responseModal.style.display = 'block';

    } catch (error) {
        closeModal();

        const responseModal = document.getElementById('responseModal');
        responseModal.className = 'modal error-modal';
        document.getElementById('response-title').textContent = 'Error';
        document.getElementById('response-message').textContent = 'Network error. Please try again.';
        responseModal.style.display = 'block';
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const confirmModal = document.getElementById('confirmModal');
    const responseModal = document.getElementById('responseModal');

    if (event.target === confirmModal) {
        closeModal();
    }
    if (event.target === responseModal) {
        closeResponseModal();
    }
}
</script>
@endpush
@endsection
