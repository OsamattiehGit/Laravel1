@extends('layouts.app')
@include('components.footer')

@section('title', 'About Us')

@section('content')
<section style="max-width: 800px; margin: auto; padding: 40px 20px;">
    <h2>About EzySkills</h2>
    <p>
        EzySkills is the world's first AI-powered online learning platform built to help students and professionals upskill
        through interactive, engaging, and structured content. Our mission is to empower the next billion learners.
    </p>

    <h3>Our Mission</h3>
    <p>To transform education using AI and human mentorship, helping people gain real-world, job-ready skills.</p>

    <h3>Our Vision</h3>
    <p>We aim to become the go-to global platform for modern upskilling, providing quality learning for all.</p>

    <h3>Meet Our Team</h3>
    <ul>
        <li><strong>Osama</strong> – Lead Trainer (AI & ML)</li>
        <li><strong>Osama Two</strong> – Cybersecurity Expert</li>
        <li><strong>Osama Three</strong> – Frontend Mentor</li>
    </ul>
</section>
@endsection
