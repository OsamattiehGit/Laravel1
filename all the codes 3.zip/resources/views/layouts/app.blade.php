<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>@yield('title','EzySkills')</title>

  {{-- Global CSS (all pages) --}}
  @vite([
    'resources/css/style.css',
    'resources/css/footer.css',
    'resources/css/pricing.css',
  ])

  {{-- Page-specific CSS --}}
  @stack('styles')
</head>
<body>
  {{-- Navbar --}}
  @include('navbar')

  {{-- Main content area (exactly one!) --}}
  <main>
    @yield('content')
  </main>

  {{-- Footer --}}
  @include('footer')

  {{-- Global JS (all pages) --}}
  @vite([
    'resources/js/main.js',
    'resources/js/admin.js',
    'resources/js/home.js',
  ])

  {{-- Page-specific JS --}}
  @stack('scripts')
</body>
</html>
