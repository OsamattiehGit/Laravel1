<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\AdminCourseController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\EnrollmentController;
use App\Http\Controllers\SubscriptionController;

use App\Models\Course;

// 🔓 Public Pages
Route::view('/', 'home');
Route::get('/home', function () {
    $courses = Course::all();  // Fetch all courses
    return view('home', compact('courses'));
});
Route::view('/faq', 'faq');
Route::view('/contact', 'contact');
Route::view('/about', 'about');
Route::view('/courses', 'courses')->name('courses');
Route::get('/course/{id}', [CourseController::class, 'show'])->name('course.show');
Route::get('/course/{course}/demo', [CourseController::class, 'demo'])->name('courses.demo');
Route::get('/course/{course}/enroll', [CourseController::class, 'enroll'])->name('courses.enroll');
Route::get('/course/{course}/download', [CourseController::class, 'download'])->name('courses.download');

// 🔒 Auth Routes (Breeze + Protected Routes)
Route::middleware('auth')->group(function () {
    Route::view('/dashboard', 'dashboard')->name('dashboard');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// ✅ CLEAN: Admin Course Routes (CRUD)
Route::middleware(['web', 'auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::resource('courses', AdminCourseController::class)->except('show');
        // This auto-defines:
        // admin.courses.index
        // admin.courses.create
        // admin.courses.store
        // admin.courses.edit
        // admin.courses.update
        // admin.courses.destroy
    });
    Route::middleware('auth')->group(function(){

    // 1) Course detail (Blade + JS will fetch JSON internally)
    Route::get('/course/{course}', [CourseController::class,'show'])
         ->name('course.show');

    // 2) Enroll via POST, returns JSON {message, balance}
    Route::post('/course/{course}/enroll', [EnrollmentController::class,'store'])
         ->name('course.enroll');

    // 3) Pricing & Subscribe
    Route::get('/pricing', [SubscriptionController::class,'pricing'])
         ->name('subscriptions.pricing');
    Route::post('/subscriptions', [SubscriptionController::class,'store'])
         ->name('subscriptions.store');
});

Route::middleware('auth')->group(function(){
    Route::get('/course/{course}', [\App\Http\Controllers\CourseController::class,'show'])
         ->name('courses.show');

    Route::post('/course/{course}/enroll', [\App\Http\Controllers\EnrollmentController::class,'store'])
         ->name('courses.enroll');

    Route::get('/pricing', [\App\Http\Controllers\SubscriptionController::class,'pricing'])
         ->name('subscriptions.pricing');
    Route::post('/subscriptions', [\App\Http\Controllers\SubscriptionController::class,'store'])
         ->name('subscriptions.store');
});
// Pricing routes
Route::get('/pricing', [SubscriptionController::class, 'index'])->name('pricing.index');
Route::post('/subscriptions', [SubscriptionController::class, 'store'])->name('subscriptions.store');

// Enrollment routes
Route::middleware('auth')->group(function () {
    Route::post('/courses/{course}/enroll', [EnrollmentController::class, 'store'])->name('courses.enroll');
});


require __DIR__.'/auth.php';
