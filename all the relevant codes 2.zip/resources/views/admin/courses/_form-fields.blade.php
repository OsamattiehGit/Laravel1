@php
  $oldObj = old('objectives', $course->objectives ?? '');
  $oldCnt = old('course_content', $course->course_content ?? '');
@endphp

<div class="admin-form-group">
  <label for="title">Title</label>
  <input
    type="text"
    name="title"
    id="title"
    class="admin-form-control @error('title') is-invalid @enderror"
    value="{{ old('title', $course->title) }}"
  >
  @error('title') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="instructor">Instructor</label>
  <input
    type="text"
    name="instructor"
    id="instructor"
    class="admin-form-control @error('instructor') is-invalid @enderror"
    value="{{ old('instructor', $course->instructor) }}"
  >
  @error('instructor') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="category_id">Category</label>
  <select
    name="category_id"
    id="category_id"
    class="admin-form-select @error('category_id') is-invalid @enderror"
  >
    <option value="">— Choose —</option>
    @foreach($categories as $cat)
      <option
        value="{{ $cat->id }}"
        {{ old('category_id', $course->category_id) == $cat->id ? 'selected' : '' }}
      >{{ $cat->name }}</option>
    @endforeach
  </select>
  @error('category_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="status">Status</label>
  <select
    name="status"
    id="status"
    class="admin-form-select @error('status') is-invalid @enderror"
  >
    <option value="opened"  {{ old('status', $course->status) == 'opened'  ? 'selected' : '' }}>Opened</option>
    <option value="soon"    {{ old('status', $course->status) == 'soon'    ? 'selected' : '' }}>Coming Soon</option>
    <option value="archived"{{ old('status', $course->status) == 'archived'? 'selected' : '' }}>Archived</option>
  </select>
  @error('status') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="image">Image (SVG/PNG/JPG)</label>
  <input
    type="file"
    name="image"
    id="image"
    class="admin-form-control @error('image') is-invalid @enderror"
  >
  @if($course->image)
    <p class="mt-2">
      <img src="{{ Storage::url($course->image) }}"
           alt="Current"
           style="max-height:60px; border:1px solid #CCC; padding:2px;">
    </p>
  @endif
  @error('image') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="description">Description</label>
  <textarea
    name="description"
    id="description"
    class="admin-form-textarea @error('description') is-invalid @enderror"
  >{{ old('description', $course->description) }}</textarea>
  @error('description') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="objectives">Objectives <small>(comma‑separated)</small></label>
  <textarea
    name="objectives"
    id="objectives"
    class="admin-form-textarea @error('objectives') is-invalid @enderror"
  >{{ is_string($oldObj) ? $oldObj : implode(',', $oldObj) }}</textarea>
  @error('objectives') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="admin-form-group">
  <label for="course_content">Course Content <small>(comma‑separated)</small></label>
  <textarea
    name="course_content"
    id="course_content"
    class="admin-form-textarea @error('course_content') is-invalid @enderror"
  >{{ is_string($oldCnt) ? $oldCnt : implode(',', $oldCnt) }}</textarea>
  @error('course_content') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>
