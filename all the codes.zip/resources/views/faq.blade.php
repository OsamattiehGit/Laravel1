@extends('layouts.app')
@include('components.footer')

@section('title', 'FAQ')

@section('content')
<section style="max-width: 800px; margin: auto;">
    <h2>Frequently Asked Questions</h2>
    <ul>
        <li>✅ Who is eligible for the program?</li>
        <li>📅 What is the duration?</li>
        <li>📜 Do I get a certificate?</li>
        <li>🎯 Can I attend if I already work?</li>
        <li>🔄 What if I miss a session?</li>
    </ul>
</section>
@endsection
