<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subscription;

class SubscriptionController extends Controller
{
    // Updated plan definitions with USD pricing
    public function subscribe(Request $request)
{
    $request->validate(['type' => 'required|in:A,B,C']);

    $credits = Subscription::getCreditsByType($request->type);

    auth()->user()->subscriptions()->create([
        'type' => $request->type,
        'course_credits' => $credits,
    ]);

    return response()->json([
        'message' => "Successfully subscribed to Plan $request->type.",
        'new_balance' => auth()->user()->course_balance,
    ]);
}

    private $plans = [
        ['id' => 'A', 'name' => 'Type A', 'price' => 49.99, 'limit' => 5],
        ['id' => 'B', 'name' => 'Type B', 'price' => 34.99, 'limit' => 3],
        ['id' => 'C', 'name' => 'Type C', 'price' => 19.99, 'limit' => 1],
    ];

    public function index()
    {
        return view('pricing', [
            'plans' => $this->plans
        ]);
    }

    public function pricing()
    {
        return view('pricing', [
            'plans' => $this->plans
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'plan_id' => 'required|in:A,B,C'
        ]);

        // Look up plan details
        $plan = collect($this->plans)
                  ->firstWhere('id', $data['plan_id']);

        if (!$plan) {
            return response()->json(['error' => 'Invalid plan selected'], 400);
        }

        // Create subscription record
        auth()->user()->subscriptions()->create([
            'plan_name'      => $plan['name'],
            'courses_allowed'=> $plan['limit'],
            'price'          => $plan['price'],
        ]);

        // Return JSON response for AJAX
        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => "Successfully subscribed to {$plan['name']}! You now have {$plan['limit']} additional course slots.",
                'plan' => $plan
            ]);
        }

        return redirect()
            ->route('pricing.index')
            ->with('success', "Subscribed to {$plan['name']} — you now have {$plan['limit']} more course slots.");
    }
}
