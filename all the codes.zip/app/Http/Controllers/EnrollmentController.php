<?php

namespace App\Http\Controllers;
use App\Models\Enrollment;
use App\Models\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;



class EnrollmentController extends Controller
{

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
public function store(Request $request)
{
    $request->validate([
        'course_id' => 'required|exists:courses,id',
    ]);

    /** @var \App\Models\User $user */
    $user = Auth::user();

    if (!$user) {
        return response()->json(['message' => 'Not authenticated.'], 401);
    }

    if ($user->remainingEnrollments() <= 0) {
        return response()->json([
            'message' => 'You have no remaining course slots. Please purchase another subscription plan.'
        ], 403);
    }

    if ($user->enrollments()->where('course_id', $request->course_id)->exists()) {
        return response()->json([
            'message' => 'You are already enrolled in this course.'
        ], 409);
    }

    $enrollment = Enrollment::create([
        'user_id' => $user->id,
        'course_id' => $request->course_id,
    ]);

    return response()->json([
        'message' => 'Successfully enrolled in course.',
        'enrollment' => $enrollment
    ], 201);
}



    /**
     * Display the specified resource.
     */
    public function show(Enrollment $enrollment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Enrollment $enrollment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Enrollment $enrollment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Enrollment $enrollment)
    {
        //
    }
}
