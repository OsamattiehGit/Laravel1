<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subscription;

class SubscriptionController extends Controller
{
    // Hard-coded plan definitions:
    private $plans = [
      ['id'=>'A','name'=>'Type A','price'=>49.99,'limit'=>5],
      ['id'=>'B','name'=>'Type B','price'=>34.99,'limit'=>3],
      ['id'=>'C','name'=>'Type C','price'=>19.99,'limit'=>1],
    ];

    public function pricing()
    {
        return view('subscriptions.pricing', [
            'plans' => $this->plans
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
          'plan_id' => 'required|in:A,B,C'
        ]);

        // look up our plan details
        $plan = collect($this->plans)
                  ->firstWhere('id', $data['plan_id']);

        auth()->user()->subscriptions()->create([
          'plan_name'      => $plan['name'],
          'courses_allowed'=> $plan['limit'],
          'price'          => $plan['price'],
        ]);

        return redirect()
            ->route('subscriptions.pricing')
            ->with('success', "Subscribed to {$plan['name']} — you now have {$plan['limit']} more course slots.");
    }
}
