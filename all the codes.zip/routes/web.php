<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\AdminCourseController;
use App\Models\Course;

// Public pages
Route::view('/', 'home');
Route::get('/home', function () {
    $courses = Course::all();
    return view('home', compact('courses'));
});
Route::view('/courses', 'courses')->name('courses');
Route::get('/course/{id}', [CourseController::class, 'show'])->name('course.show');

// Course actions (demo/enroll/download)
Route::get('/course/{course}/demo', [CourseController::class, 'demo'])->name('courses.demo');
Route::get('/course/{course}/enroll', [CourseController::class, 'enroll'])->name('courses.enroll');
Route::get('/course/{course}/download', [CourseController::class, 'download'])->name('courses.download');

// Admin Course Management
Route::get('/admin/courses', [AdminCourseController::class, 'index'])->name('admin.courses');
Route::post('/admin/courses', [AdminCourseController::class, 'store'])->name('admin.courses.store');
Route::get('/admin/courses/{id}/edit', [AdminCourseController::class, 'edit'])->name('admin.courses.edit');
Route::put('/admin/courses/{id}', [AdminCourseController::class, 'update'])->name('admin.courses.update');
Route::delete('/admin/courses/{id}', [AdminCourseController::class, 'destroy'])->name('admin.courses.delete');

// Static pages
Route::view('/faq', 'faq');
Route::view('/pricing', 'pricing');
Route::view('/contact', 'contact');
Route::view('/about', 'about');

// Auth (Breeze)
Route::view('/login', 'auth.login')->name('login');
Route::view('/register', 'auth.register')->name('register');

Route::middleware('auth')->group(function () {
    Route::view('/dashboard', 'dashboard')->name('dashboard');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
