@extends('layouts.app')

<!DOCTYPE html>
@section('title', 'Pricing')
@section('content')
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pricing | EzySkills</title>
@vite(['resources/css/pricing.css', 'resources/js/main.js'])
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>


  <section class="pricing-title">
    <h2>Our <span>Pricing</span></h2>
  </section>

  <section class="pricing-cards">
    <div class="card college">
      <div class="label">College Program</div>
      <h3>$ 20<span>+ Tax</span></h3>
      <p>(Exclusive of GST & Taxes)</p>
      <ul>
        <li><i class="fa fa-building-columns"></i> For Colleges, Universities & Groups</li>
        <li><i class="fa fa-clock"></i> Common Timings</li>
      </ul>
      <button>Choose Plan</button>
    </div>

    <div class="card employee">
      <div class="label">Employee Program</div>
      <h3>$ 35<span>+ Tax</span></h3>
      <p>(Exclusive of GST & Taxes)</p>
      <ul>
        <li><i class="fa fa-user"></i> 1-1 Individuals</li>
        <li><i class="fa fa-calendar"></i> Choose Timings</li>
      </ul>
      <button>Choose Plan</button>
    </div>

    <div class="card transformation">
      <div class="label">Complete Transformation Program</div>
      <h3>$ 50 <span>+ Tax</span></h3>
      <p>(Exclusive of GST & Taxes)</p>
      <ul>
        <li><i class="fa fa-user"></i> 1-1 Individuals</li>
        <li><i class="fa fa-clock-rotate-left"></i> Flexible Timings</li>
      </ul>
      <button>Choose Plan</button>
    </div>
  </section>

@endsection
