<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Http\Request;
use App\Http\Requests\StoreCourseRequest;
use App\Http\Requests\UpdateCourseRequest;
use App\Http\Resources\CourseResource;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
class CourseController extends Controller
{
 public function index(Request $request)
    {
        $q      = $request->input('q', '');
        $filter = $request->input('filter', 'all');
        $sort   = $request->input('sort', 'popular');

       $query = Course::withCount('enrollments');

        // 1) Search
        if ($q !== '') {
            $query->where(function($q2) use($q){
                $q2->where('title', 'like', "%{$q}%")
                   ->orWhere('description', 'like', "%{$q}%");
            });
        }

        // 2) Filter by status
        if (in_array($filter, ['opened','soon','archived'])) {
            $query->where('status', $filter);
        }

        // 3) Sort
        switch ($sort) {
            case 'newest':
                $query->orderBy('created_at','desc');
                break;
            case 'title':
                $query->orderBy('title','asc');
                break;
            case 'popular':
            default:
                // we assume you have an enrollments_count column or relation
                $query->orderBy('enrollments_count','desc');
                break;
        }

        // 4) Paginate 8 per page
        $perPage = 8;
        $page    = (int) $request->input('page', 1);

        $paginator = $query->paginate($perPage, ['*'], 'page', $page);

        // 5) Return JSON in the shape your JS expects
        return response()->json([
            'data' => $paginator->items(),
            'meta' => [
                'current_page' => $paginator->currentPage(),
                'last_page'    => $paginator->lastPage(),
                'per_page'     => $paginator->perPage(),
                'total'        => $paginator->total(),
            ],
        ]);
    }


    public function show($id)
    {
        $course = Course::with('category')->withCount('enrollments')->findOrFail($id);
        return response()->json(['data' => $course]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'instructor' => 'required|string',
            'status' => 'required|in:opened,soon,archived',
            'objectives' => 'nullable|array',
            'course_content' => 'nullable|array',
            'user_id' => 'nullable|integer',
            'image' => 'nullable|image|mimes:svg,png,jpg,jpeg|max:2048',
        ]);
if ($request->hasFile('image')) {
    $file = $request->file('image');
    $filename = time() . '.' . $file->getClientOriginalExtension();
    $path = $file->storeAs('uploads/courses', $filename, 'public');
    $validated['image'] = 'storage/' . $path;
}

        $validated['objectives'] = json_encode($validated['objectives'] ?? []);
        $validated['course_content'] = json_encode($validated['course_content'] ?? []);
        $validated['user_id'] = $validated['user_id'] ?? 1;

        $course = Course::create($validated);
        return response()->json(['data' => $course], 201);
    }

    public function update(Request $request, $id)
    {
        $course = Course::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'instructor' => 'required|string',
            'objectives' => 'nullable|array',
            'course_content' => 'nullable|array',
        ]);

        $validated['objectives'] = json_encode($validated['objectives'] ?? []);
        $validated['course_content'] = json_encode($validated['course_content'] ?? []);

        $course->update($validated);

       return response()->json(['data' => $course->fresh()->load('category')]);
    }

    public function destroy($id)
    {
        $course = Course::findOrFail($id);

if ($course->image && file_exists(public_path($course->image))) {
    unlink(public_path($course->image));
}

$course->delete();

        return response()->json(['message' => 'Deleted']);
    }
}
