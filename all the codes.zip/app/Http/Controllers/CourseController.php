<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Http\Request;
use App\Http\Requests\StoreCourseRequest;
use App\Http\Requests\UpdateCourseRequest;
use App\Http\Resources\CourseResource;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
class CourseController extends Controller
{
  public function index(Request $request)
{
    $query = Course::with('category');

    if ($search = $request->q) {
        $query->where('title', 'LIKE', "%$search%");
    }

    // Filtering logic
    if ($request->filter === 'opened') {
        $query->where('status', 'opened');
    } elseif ($request->filter === 'soon') {
        $query->where('status', 'soon');
    } elseif ($request->filter === 'archived') {
        $query->where('status', 'archived');
    }

    // Sorting logic
    if ($request->sort === 'title') {
        $query->orderBy('title');
    } elseif ($request->sort === 'newest') {
        $query->latest();
    } else {
        $query->withCount('enrollments')->orderByDesc('enrollments_count');
    }

    return CourseResource::collection($query->paginate(8));
}


    public function show($id)
    {
        $course = Course::with('category')->withCount('enrollments')->findOrFail($id);
        return response()->json(['data' => $course]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'instructor' => 'required|string',
            'objectives' => 'nullable|array',
            'course_content' => 'nullable|array',
            'user_id' => 'nullable|integer',
            'image' => 'nullable|image|mimes:svg,png,jpg,jpeg|max:2048',
        ]);
if ($request->hasFile('image')) {
    $file = $request->file('image');
    $filename = time() . '.' . $file->getClientOriginalExtension();
    $path = $file->storeAs('uploads/courses', $filename, 'public');
    $validated['image'] = 'storage/' . $path;
}

        $validated['objectives'] = json_encode($validated['objectives'] ?? []);
        $validated['course_content'] = json_encode($validated['course_content'] ?? []);
        $validated['user_id'] = $validated['user_id'] ?? 1;

        $course = Course::create($validated);
        return response()->json(['data' => $course], 201);
    }

    public function update(Request $request, $id)
    {
        $course = Course::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'instructor' => 'required|string',
            'objectives' => 'nullable|array',
            'course_content' => 'nullable|array',
        ]);

        $validated['objectives'] = json_encode($validated['objectives'] ?? []);
        $validated['course_content'] = json_encode($validated['course_content'] ?? []);

        $course->update($validated);

       return response()->json(['data' => $course->fresh()->load('category')]);
    }

    public function destroy($id)
    {
        $course = Course::findOrFail($id);

if ($course->image && file_exists(public_path($course->image))) {
    unlink(public_path($course->image));
}

$course->delete();

        return response()->json(['message' => 'Deleted']);
    }
}
