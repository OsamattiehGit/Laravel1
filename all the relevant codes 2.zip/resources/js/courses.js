// Just one module: search + filter + sort + pagination
document.addEventListener('DOMContentLoaded', () => {
  const grid    = document.getElementById('course-list');
  const search  = document.getElementById('search-box');
  const filters = document.querySelectorAll('.filter-btn');
  const sortSel = document.getElementById('sort-select');
  const pager   = document.getElementById('pagination');

  if (!grid) return;

  // wire up events
  search.addEventListener('input', debounce(() => load(1), 300));
  filters.forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelector('.filter-btn.active').classList.remove('active');
      btn.classList.add('active');
      load(1);
    });
  });
  sortSel.addEventListener('change', () => load(1));

  // initial load
  load(1);

  // core loader
  function load(page) {
    const q      = search.value.trim();
    const filter = document.querySelector('.filter-btn.active').dataset.filter;
    const sort   = sortSel.value;
    const params = new URLSearchParams({ page, q, filter, sort });

    fetch(`${window.location.origin}/api/courses?${params}`)
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(json => {
        render(json.data);
        renderPager(json.meta);
      })
      .catch(err => {
        console.error('Error loading courses:', err);
        grid.innerHTML = `<p style="text-align:center;color:red;">
                            Failed to load courses.
                          </p>`;
      });
  }

  // render grid
  function render(courses) {
    grid.innerHTML = '';
    if (!courses.length) {
      grid.innerHTML = `<p style="text-align:center;">No courses found.</p>`;
      return;
    }
    courses.forEach(c => {
      const url = c.image
        ? `${window.location.origin}/storage/${c.image}`
        : '/images/default-course.png';

      const div = document.createElement('div');
      div.className = 'course-card';
      div.innerHTML = `
        <div class="course-card-inner">
          <div class="course-card-top">
            <img src="${url}" alt="${c.title}">
          </div>
          <div class="course-card-bottom">
            <h4>${c.title}</h4>
            <p>${c.description.slice(0,100)}…</p>
            <div class="course-card-actions">
              <a href="/course/${c.id}"       class="btn-demo">
                <i class="fa fa-play-circle"></i>
                Live Demo
              </a>
              <a href="/course/${c.id}/enroll" class="btn-enroll">
                <i class="fa fa-user-plus"></i>
                Enroll Now
              </a>
            </div>
            <a href="/course/${c.id}/download" class="btn-download">
              <i class="fa fa-download"></i>
              Download Curriculum
            </a>
          </div>
        </div>`;
      grid.appendChild(div);
    });
  }

  // render pagination
  function renderPager(meta) {
    pager.innerHTML = '';
    if (meta.last_page <= 1) return;

    for (let i = 1; i <= meta.last_page; i++) {
      const b = document.createElement('button');
      b.textContent = i;
      if (i === meta.current_page) b.classList.add('active');
      b.addEventListener('click', () => load(i));
      pager.appendChild(b);
    }
  }

  // simple debounce
  function debounce(fn, delay) {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), delay);
    };
  }
});
