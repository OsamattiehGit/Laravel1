<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AdminCourseController extends Controller
{
    public function index()
    {
        $courses = Course::with('category')->paginate(10);
        $categories = Category::all();
        return view('admin.courses.index', compact('courses','categories'));
    }

       public function store(Request $request)
    {
        // 1) validate everything (incl. new_category)
        $validated = $request->validate([
            'title'          => 'required|string|max:255',
            'description'    => 'required|string',
            'instructor'     => 'required|string|max:255',
            'category_id'    => 'required',
            'new_category'   => 'nullable|string|max:50',
            'status'         => 'required|in:opened,soon,archived',
            'objectives'     => 'nullable|string',
            'course_content' => 'nullable|string',
            'image'          => 'nullable|image|mimes:svg,png,jpg,jpeg|max:2048',
        ]);

        // 2) handle “Add New Category”
        if ($validated['category_id'] === '__new__') {
            if (empty($validated['new_category'])) {
                return back()
                    ->withErrors(['new_category' => 'Please enter the new category name.'])
                    ->withInput();
            }
            $cat = Category::firstOrCreate([ 'name' => $validated['new_category'] ]);
            $validated['category_id'] = $cat->id;
        }

        // 3) handle image upload
        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')
                                         ->store('courses','public');
        }

        // 4) split comma‑lists into arrays & JSON‑encode
        $objectives = array_filter(array_map('trim', explode(',', $validated['objectives'] ?? '')));
        $content    = array_filter(array_map('trim', explode(',', $validated['course_content'] ?? '')));

        // 5) create
        Course::create([
            'title'          => $validated['title'],
            'description'    => $validated['description'],
            'instructor'     => $validated['instructor'],
            'category_id'    => $validated['category_id'],
            'status'         => $validated['status'],
            'objectives'     => json_encode($objectives),
            'course_content' => json_encode($content),
            'image'          => $validated['image'] ?? null,
            'user_id'        => auth()->id(),
        ]);

        return redirect()
            ->route('admin.courses.index')
            ->with('success','Course added successfully.');
    }


    public function edit(Course $course)
    {
        $categories = Category::all();
        return view('admin.courses.edit', compact('course','categories'));
    }

    public function update(Request $request, Course $course)
    {
        // 1) validate
        $validated = $request->validate([
            'title'          => 'required|string|max:255',
            'description'    => 'required|string',
            'instructor'     => 'required|string|max:255',
            'category_id'    => 'required',
            'new_category'   => 'nullable|string|max:50',
            'status'         => 'required|in:opened,soon,archived',
            'objectives'     => 'nullable|string',
            'course_content' => 'nullable|string',
            'image'          => 'nullable|image|mimes:svg,png,jpg,jpeg|max:2048',
        ]);

        // 2) handle new category
        if ($validated['category_id'] === '__new__') {
            if (empty($validated['new_category'])) {
                return back()
                    ->withErrors(['new_category' => 'Please enter the new category name.'])
                    ->withInput();
            }
            $cat = Category::firstOrCreate([ 'name' => $validated['new_category'] ]);
            $validated['category_id'] = $cat->id;
        }

        // 3) handle replacement image
        if ($request->hasFile('image')) {
            if ($course->image) {
                Storage::disk('public')->delete($course->image);
            }
            $validated['image'] = $request->file('image')
                                         ->store('courses','public');
        }

        // 4) split & JSON‑encode
        $objectives = array_filter(array_map('trim', explode(',', $validated['objectives'] ?? '')));
        $content    = array_filter(array_map('trim', explode(',', $validated['course_content'] ?? '')));

        // 5) update
        $course->update([
            'title'          => $validated['title'],
            'description'    => $validated['description'],
            'instructor'     => $validated['instructor'],
            'category_id'    => $validated['category_id'],
            'status'         => $validated['status'],
            'objectives'     => json_encode($objectives),
            'course_content' => json_encode($content),
            'image'          => $validated['image'] ?? $course->image,
        ]);

        return redirect()
            ->route('admin.courses.index')
            ->with('success','Course updated successfully.');
    }

    public function destroy(Course $course)
    {
        if ($course->image) {
            Storage::disk('public')->delete($course->image);
        }
        $course->delete();

        return redirect()->route('admin.courses.index')
                         ->with('success', 'Course deleted successfully.');
    }
}
