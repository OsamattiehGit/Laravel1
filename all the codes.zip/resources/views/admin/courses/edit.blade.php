@extends('layouts.app')

@section('content')
<div class="container py-4">
    <h2 class="mb-4 text-center text-primary"><strong>Edit Course</strong></h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card">
        <div class="card-header bg-warning text-dark">Edit Course</div>
        <div class="card-body">
            <form action="{{ route('admin.courses.update', $course->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('POST')

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="title">Title</label>
                        <input type="text" name="title" id="title" class="form-control" value="{{ old('title', $course->title) }}" required>
                    </div>

                    <div class="col-md-6">
                        <label for="instructor">Instructor</label>
                        <input type="text" name="instructor" id="instructor" class="form-control" value="{{ old('instructor', $course->instructor) }}" required>
                    </div>

                    <div class="col-md-6">
                        <label for="category_id">Category</label>
                        <select name="category_id" id="category_id" class="form-control" required>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ $course->category_id == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="image">Image (SVG / PNG / JPG)</label>
                        <input type="file" name="image" id="image" class="form-control" accept=".svg,.png,.jpg,.jpeg">
                        @if($course->image)
                            <small class="d-block mt-1">Current: <img src="{{ asset($course->image) }}" alt="Course Image" height="50"></small>
                        @endif
                    </div>

                    <div class="col-12">
                        <label for="description">Description</label>
                        <textarea name="description" id="description" rows="2" class="form-control" required>{{ old('description', $course->description) }}</textarea>
                    </div>

                    <div class="col-12">
                        <label for="objectives">Objectives <small>(Comma-separated)</small></label>
                        <textarea name="objectives" id="objectives" rows="2" class="form-control">{{ old('objectives', implode(', ', json_decode($course->objectives ?? '[]'))) }}</textarea>
                    </div>

                    <div class="col-12">
                        <label for="course_content">Course Content <small>(Comma-separated)</small></label>
                        <textarea name="course_content" id="course_content" rows="2" class="form-control">{{ old('course_content', implode(', ', json_decode($course->course_content ?? '[]'))) }}</textarea>
                    </div>

                    <div class="col-12 text-end">
                        <a href="{{ route('admin.courses.index') }}" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-success">Update Course</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
