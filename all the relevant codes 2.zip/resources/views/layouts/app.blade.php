
<!DOCTYPE html>
 @stack('scripts')
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Ezyskills')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    {{-- FontAwesome CDN --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    {{-- Your custom CSS --}}
    @vite(['resources/css/style.css', 'resources/css/pricing.css','resources/css/footer.css'])
      @stack('styles')
</head>
<body>
    @include('navbar')

    <main>
      @yield('content')
    </main>
    {{-- Footer --}}
   @include('footer')

    {{-- Scripts --}}
    {{-- Your custom JS --}}
    @vite(['resources/js/main.js','resources/js/admin.js','resources/js/course.js','resources/js/home.js'])

    {{-- Additional scripts can be added here --}}
</body>
</html>
