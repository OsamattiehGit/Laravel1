window.addEventListener("DOMContentLoaded", () => {


    const API_URL = "/api/courses";
    const form = document.getElementById("course-form");
    const courseList = document.getElementById("course-list");
    const clearBtn = document.getElementById("clear-form");

    if (!form) {
        console.warn("❌ Form not found");
        return;
    }

document.addEventListener("DOMContentLoaded", function () {
  const categorySelect = document.getElementById("category_id");
  const newCatContainer = document.getElementById("new-category-container");
  const newCatInput = document.getElementById("new_category");

  if (categorySelect) {
    categorySelect.addEventListener("change", () => {
      if (categorySelect.value === "__new__") {
        newCatContainer.style.display = "block";
      } else {
        newCatContainer.style.display = "none";
        newCatInput.value = "";
      }
    });
  }

  // …the rest of your admin.js logic…
});

    form.addEventListener("submit", async e => {
        e.preventDefault();

        const id = document.getElementById("course-id").value;
        const objectives = document.getElementById('objectives')?.value.split(',').map(str => str.trim()).filter(Boolean) || [];
        const courseContent = document.getElementById('course_content')?.value.split(',').map(str => str.trim()).filter(Boolean) || [];

        const formData = new FormData();
        formData.append("title", document.getElementById('title').value);
        formData.append("description", document.getElementById('description').value);
        formData.append("instructor", document.getElementById('instructor').value);
        formData.append("category_id", document.getElementById('category_id').value);
        formData.append("user_id", 1); // Assuming admin
        formData.append("status", document.getElementById('status').value);
        formData.append("objectives", JSON.stringify(objectives));
        formData.append("course_content", JSON.stringify(courseContent));

        const imageInput = document.getElementById("image");
        if (imageInput?.files?.length > 0) {
            formData.append("image", imageInput.files[0]);
        }

        const url = id ? `${API_URL}/${id}` : API_URL;
        const method = id ? "POST" : "POST";
        if (id) formData.append("_method", "PUT");

        try {
            const res = await fetch(url, { method, body: formData });
            const data = await res.json();
            console.log("✅ Saved:", data);
            resetForm();
            loadCourses();
        } catch (err) {
            console.error("❌ Save failed:", err);
            alert("Error saving course — check console.");
        }
    });

    function resetForm() {
        form.reset();
        document.getElementById("course-id").value = "";
    }

    function loadCourses() {
        if (!courseList) return;
        courseList.innerHTML = "";
        fetch(API_URL)
            .then(res => res.json())
            .then(data => {
                data.data.forEach(course => {
                    const card = document.createElement("div");
                    card.className = "course-card col-md-4";

                    card.innerHTML = `
                        ${course.image ? `<img src="/${course.image}" class="img-fluid" alt="Course Image">` : ''}
                        <h5>${course.title}</h5>
                        <p>${course.description}</p>
                        <small>Instructor: ${course.instructor} | Enrollments: ${course.enrollments_count}</small>
                        <p><strong>Objectives:</strong> ${Array.isArray(course.objectives) ? course.objectives.join(', ') : 'N/A'}</p>
                        <p><strong>Content:</strong> ${Array.isArray(course.course_content) ? course.course_content.join(', ') : 'N/A'}</p>
                        <button onclick="editCourse(${course.id})" class="btn btn-sm btn-warning me-2">Edit</button>
                        <button onclick="deleteCourse(${course.id})" class="btn btn-sm btn-danger">Delete</button>
                    `;
                    courseList.appendChild(card);
                });
            });
    }

    window.editCourse = function (id) {
        fetch(`${API_URL}/${id}`)
            .then(res => res.json())
            .then(data => {
                const c = data.data;
                document.getElementById("course-id").value = c.id;
                form.title.value = c.title;
                form.description.value = c.description;
                form.instructor.value = c.instructor;
                form.category_id.value = c.category_id;
                form.objectives.value = Array.isArray(c.objectives) ? c.objectives.join(', ') : '';
                form.course_content.value = Array.isArray(c.course_content) ? c.course_content.join(', ') : '';
                document.getElementById("status").value = c.status;
                window.scrollTo(0, 0);
            });
    }

    window.deleteCourse = function (id) {
        if (!confirm("Delete this course?")) return;
        fetch(`${API_URL}/${id}`, { method: "DELETE" })
            .then(() => loadCourses())
            .catch(err => console.error("❌ Delete failed:", err));
    };

    if (clearBtn) {
        clearBtn.addEventListener("click", resetForm);
    }

    loadCourses();
});
