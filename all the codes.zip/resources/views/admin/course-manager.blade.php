@extends('layouts.app')

@section('content')
<div class="container py-4">
    <h2 class="mb-4 text-center text-primary"><strong>Admin Course Manager</strong></h2>

    <div id="success-alert" class="alert alert-success d-none"></div>
    <div id="error-alert" class="alert alert-danger d-none"></div>

    <!-- Add Course Form -->
    <div class="card mb-5">
        <div class="card-header bg-primary text-white">Add New Course</div>
        <div class="card-body">
           <form id="course-form" enctype="multipart/form-data">
                @csrf
<input type="hidden" id="course-id" name="id">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="title">Title</label>
                        <input type="text" id="title" class="form-control" required>
                    </div>

                    <div class="col-md-6">
                        <label for="instructor">Instructor</label>
                        <input type="text" id="instructor" class="form-control" required>
                    </div>

                    <div class="col-md-6">
                        <label for="category_id">Category</label>
                        <select id="category_id" class="form-control" required>
                            <option value="">-- Select Category --</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="status">Status</label>
                        <select id="status" class="form-control" required>
                            <option value="opened" selected>Opened</option>
                            <option value="soon">Coming Soon</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="image">Image (SVG / PNG / JPG)</label>
                        <input type="file" id="image" class="form-control" accept=".svg,.png,.jpg,.jpeg">
                    </div>

                    <div class="col-12">
                        <label for="description">Description</label>
                        <textarea id="description" rows="2" class="form-control" required></textarea>
                    </div>

                    <div class="col-12">
                        <label for="objectives">Objectives <small>(Comma-separated)</small></label>
                        <textarea id="objectives" rows="2" class="form-control" required></textarea>
                    </div>

                    <div class="col-12">
                        <label for="course_content">Course Content <small>(Comma-separated)</small></label>
                        <textarea id="course_content" rows="2" class="form-control" required></textarea>
                    </div>

                    <div class="col-12 text-end">
                        <button type="submit" class="btn btn-success mt-2">Save Course</button>
                        <button type="button" id="clear-form" class="btn btn-secondary mt-2">Clear Form</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Dynamic Courses List -->
    <div class="card">
        <div class="card-header bg-dark text-white">Current Courses</div>
        <div class="card-body">
            <div id="course-list" class="row g-3">
                <!-- Course cards will be injected here via JavaScript -->
            </div>
        </div>
    </div>
</div>
@endsection
