<header style="background-color: white; padding: 3px 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
    <nav style="display: flex; align-items: center; justify-content: space-between;">

        <!-- Logo -->
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="EzySkills Logo" style="height: 50px;">
        </a>

        <!-- Navigation Links -->
        <ul style="list-style: none; display: flex; gap: 25px; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; font-weight: 500;">
            <?php $current = Request::path(); ?>

            <li><a href="<?php echo e(url('/home')); ?>"
                style="text-decoration: none; color: <?php echo e($current == '/' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == '/home' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/home'){ this.style.color='#333'; this.style.borderBottom='none'; }">Home</a></li>

            <li><a href="<?php echo e(url('/courses')); ?>"
                style="text-decoration: none; color: <?php echo e($current == 'courses' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == 'courses' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/courses'){ this.style.color='#333'; this.style.borderBottom='none'; }">Course Selector</a></li>
                <li><a href="<?php echo e(url('/courses')); ?>"
                style="text-decoration: none; color: <?php echo e($current == 'courses' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == 'courses' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/courses'){ this.style.color='#333'; this.style.borderBottom='none'; }">Courses</a></li>
           <li><a href="<?php echo e(url('/pricing')); ?>"
                style="text-decoration: none; color: <?php echo e($current == 'faq' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == 'pricing' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/pricing'){ this.style.color='#333'; this.style.borderBottom='none'; }">Prices</a></li>
            <li><a href="<?php echo e(url('/faq')); ?>"
                style="text-decoration: none; color: <?php echo e($current == 'faq' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == 'faq' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/faq'){ this.style.color='#333'; this.style.borderBottom='none'; }">FAQ</a></li>

            <li><a href="<?php echo e(url('/contact')); ?>"
                style="text-decoration: none; color: <?php echo e($current == 'contact' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == 'contact' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/contact'){ this.style.color='#333'; this.style.borderBottom='none'; }">Contact</a></li>

            <li><a href="<?php echo e(url('/about')); ?>"
                style="text-decoration: none; color: <?php echo e($current == 'about' ? '#f37021' : '#333'); ?>;
                       border-bottom: <?php echo e($current == 'about' ? '2px solid #f37021' : 'none'); ?>;
                       padding-bottom: 4px;"
                onmouseover="this.style.color='#f37021'; this.style.borderBottom='2px solid #f37021';"
                onmouseout="if(location.pathname !== '/about'){ this.style.color='#333'; this.style.borderBottom='none'; }">About US</a></li>
        </ul>

        <!-- Auth Buttons -->
        <div style="display: flex; gap: 10px; align-items: center;">
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" style="padding: 8px 20px; border: 1px solid #f37021; color: #f37021; border-radius: 4px; text-decoration: none;">Log In</a>
                <a href="<?php echo e(route('register')); ?>" style="padding: 8px 20px; background-color: #f37021; color: white; border-radius: 4px; text-decoration: none;">Create Account</a>
            <?php else: ?>
                <a href="<?php echo e(route('profile.edit')); ?>" title="Settings">
                    <img src="<?php echo e(asset('images/settings-icon.svg')); ?>" alt="Settings" style="height: 24px;">
                </a>
                <a href="<?php echo e(url('/profile')); ?>" title="Profile">
                    <img src="<?php echo e(asset('images/profile-icon.png')); ?>" alt="Profile" style="height: 28px; border-radius: 50%;">
                </a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="padding: 8px 20px; background-color: #f37021; color: white; border: none; border-radius: 4px; cursor: pointer;">Logout</button>
                </form>
            <?php endif; ?>
        </div>
    </nav>
</header>
<?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/navbar.blade.php ENDPATH**/ ?>