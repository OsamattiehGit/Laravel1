<?php $__env->startSection('title', 'Admin Course Manager'); ?>

<?php $__env->startPush('styles'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin.css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="admin-container">

  <h1 class="admin-title">Admin Course Manager</h1>

  <div class="admin-row">

    
    <div>
      <div class="admin-card">
        <div class="admin-card-header">Add New Course</div>
        <div class="admin-card-body">
          <form method="POST" action="<?php echo e(route('admin.courses.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('admin.courses._form-fields', [
              'course'     => new App\Models\Course,
              'categories' => $categories,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="admin-form-group">
              <button type="submit" class="admin-btn admin-btn-primary">Save Course</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    
    <div>
      <div class="admin-card">
        <div class="admin-card-header">Current Courses</div>
        <div class="admin-card-body">
          <table class="admin-table">
            <?php echo $__env->make('admin.courses._table', ['courses' => $courses], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          </table>

          <div class="mt-3">
            <?php echo e($courses->links()); ?>

          </div>
        </div>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>