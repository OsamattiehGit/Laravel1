document.addEventListener("DOMContentLoaded", () => {
    const pathParts = window.location.pathname.split('/');
    const courseId = parseInt(pathParts[pathParts.length - 1]);

    if (isNaN(courseId)) return;

    fetch(`/api/courses/${courseId}`)
        .then(response => response.json())
        .then(data => {
            const course = data.data;

            document.body.innerHTML = `
                <div class="container mt-4">
                    <h1>${course.title}</h1>
                    <p>${course.description}</p>
                    <p><strong>Instructor:</strong> ${course.instructor}</p>
                    <p><strong>Enrollments:</strong> ${course.enrollments_count}</p>
                </div>
            `;

            const enrollButton = document.createElement("button");
            enrollButton.textContent = "Enroll";
            enrollButton.className = "btn btn-primary mt-3";

            enrollButton.addEventListener("click", () => {
                fetch("/api/enrollments", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ course_id: course.id })
                })
                .then(res => res.json())
                .then(res => alert(res.message || "Enrolled!"))
                .catch(err => alert("Enrollment failed"));
            });

            document.body.appendChild(enrollButton);
        })
        .catch(err => {
            console.error("Failed to fetch course:", err);
            document.body.innerHTML = "<h2>Course not found</h2>";
        });
});
