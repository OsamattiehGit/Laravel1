@extends('layouts.app')

@section('content')
<div class="container mx-auto py-8">
  <h1 class="text-3xl font-bold mb-6">Our Pricing</h1>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    @foreach($plans as $plan)
      <div class="p-6 border rounded-lg text-center">
        <h2 class="text-xl font-semibold">{{ $plan['name'] }}</h2>
        <p class="mt-2 text-2xl">${{ number_format($plan['price'],2) }}</p>
        <p class="mt-1 text-gray-600">{{ $plan['limit'] }} course{{ $plan['limit']>1?'s':'' }} allowed</p>
        <form method="POST" action="{{ route('subscriptions.store') }}" class="mt-4">
          @csrf
          <input type="hidden" name="plan_id" value="{{ $plan['id'] }}">
          <button
            type="submit"
            class="px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700">
            Choose Plan
          </button>
        </form>
      </div>
    @endforeach
  </div>

  @if(session('success'))
    <div class="mt-6 p-4 bg-green-100 text-green-800 rounded">
      {{ session('success') }}
    </div>
  @endif
</div>
@endsection
