<?php $__env->startPush('styles'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin.css'); ?>
<?php $__env->stopPush(); ?>

<?php
  $oldObj = old('objectives', $course->objectives ?? '');
  $oldCnt = old('course_content', $course->course_content ?? '');
?>

<div class="admin-form-group">
  <label for="title">Title</label>
  <input
    type="text"
    name="title"
    id="title"
    class="admin-form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    value="<?php echo e(old('title', $course->title)); ?>"
  >
  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="instructor">Instructor</label>
  <input
    type="text"
    name="instructor"
    id="instructor"
    class="admin-form-control <?php $__errorArgs = ['instructor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    value="<?php echo e(old('instructor', $course->instructor)); ?>"
  >
  <?php $__errorArgs = ['instructor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="category_id">Category</label>
  <select
    name="category_id"
    id="category_id"
    class="admin-form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  >
    <option value="">— Choose —</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option
        value="<?php echo e($cat->id); ?>"
        <?php echo e(old('category_id', $course->category_id) == $cat->id ? 'selected' : ''); ?>

      ><?php echo e($cat->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="status">Status</label>
  <select
    name="status"
    id="status"
    class="admin-form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  >
    <option value="opened"  <?php echo e(old('status', $course->status) == 'opened'  ? 'selected' : ''); ?>>Opened</option>
    <option value="soon"    <?php echo e(old('status', $course->status) == 'soon'    ? 'selected' : ''); ?>>Coming Soon</option>
    <option value="archived"<?php echo e(old('status', $course->status) == 'archived'? 'selected' : ''); ?>>Archived</option>
  </select>
  <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="image">Image (SVG/PNG/JPG)</label>
  <input
    type="file"
    name="image"
    id="image"
    class="admin-form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  >
  <?php if($course->image): ?>
    <p class="mt-2">
      <img src="<?php echo e(Storage::url($course->image)); ?>"
           alt="Current"
           style="max-height:60px; border:1px solid #CCC; padding:2px;">
    </p>
  <?php endif; ?>
  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="description">Description</label>
  <textarea
    name="description"
    id="description"
    class="admin-form-textarea <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  ><?php echo e(old('description', $course->description)); ?></textarea>
  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="objectives">Objectives <small>(comma‑separated)</small></label>
  <textarea
    name="objectives"
    id="objectives"
    class="admin-form-textarea <?php $__errorArgs = ['objectives'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  ><?php echo e(is_string($oldObj) ? $oldObj : implode(',', $oldObj)); ?></textarea>
  <?php $__errorArgs = ['objectives'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="admin-form-group">
  <label for="course_content">Course Content <small>(comma‑separated)</small></label>
  <textarea
    name="course_content"
    id="course_content"
    class="admin-form-textarea <?php $__errorArgs = ['course_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  ><?php echo e(is_string($oldCnt) ? $oldCnt : implode(',', $oldCnt)); ?></textarea>
  <?php $__errorArgs = ['course_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php
  // Projects
  $rawProjects = old('projects', $course->projects ?? []);
  if (is_string($rawProjects)) {
    $projects = json_decode($rawProjects, true) ?: [];
  } elseif (is_array($rawProjects)) {
    $projects = $rawProjects;
  } else {
    $projects = [];
  }

  // Tools
  $rawTools = old('tools', $course->tools ?? []);
  if (is_string($rawTools)) {
    $tools = json_decode($rawTools, true) ?: [];
  } elseif (is_array($rawTools)) {
    $tools = $rawTools;
  } else {
    $tools = [];
  }

  // Guarantee at least one blank row
  if (count($projects) === 0) {
    $projects[] = ['icon'=>'','title'=>'','subtitle'=>''];
  }
  if (count($tools) === 0) {
    $tools[] = ['icon'=>'','name'=>''];
  }
?>


<div class="admin-form-group">
  <label>Projects</label>
  <div id="projects-wrapper">
    
    <?php if(count($projects) === 0): ?>
      <?php $projects[] = ['icon'=>'','title'=>'','subtitle'=>'']; ?>
    <?php endif; ?>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="repeatable-item mb-3">
        
        <?php if(!empty($proj['icon'])): ?>
          <p>
            <img src="<?php echo e(Storage::url($proj['icon'])); ?>"
                 alt=""
                 style="max-height:50px;">
          </p>
        <?php endif; ?>

        
        <input type="hidden"
               name="projects[<?php echo e($i); ?>][_icon]"
               value="<?php echo e($proj['icon']); ?>">

        
        <input type="file"
               name="projects[<?php echo e($i); ?>][icon]"
               class="admin-form-control mb-1 <?php $__errorArgs = ['projects.'.$i.'.icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['projects.'.$i.'.icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <input type="text"
               name="projects[<?php echo e($i); ?>][title]"
               placeholder="Project title"
               value="<?php echo e($proj['title'] ?? ''); ?>"
               class="admin-form-control mb-1 <?php $__errorArgs = ['projects.'.$i.'.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['projects.'.$i.'.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <input type="text"
               name="projects[<?php echo e($i); ?>][subtitle]"
               placeholder="Subtitle"
               value="<?php echo e($proj['subtitle'] ?? ''); ?>"
               class="admin-form-control mb-1 <?php $__errorArgs = ['projects.'.$i.'.subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['projects.'.$i.'.subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button type="button"
                class="admin-btn admin-btn-danger remove-project">
          Remove
        </button>
        <hr>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <button type="button"
          id="add-project"
          class="admin-btn admin-btn-secondary">
    + Add Project
  </button>
</div>


<div class="admin-form-group">
  <label>Tools &amp; Platforms</label>
  <div id="tools-wrapper">
    <?php if(count($tools) === 0): ?>
      <?php $tools[] = ['icon'=>'','name'=>'']; ?>
    <?php endif; ?>

    <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="repeatable-item mb-3">
        <?php if(!empty($tool['icon'])): ?>
          <p>
            <img src="<?php echo e(Storage::url($tool['icon'])); ?>"
                 alt=""
                 style="max-height:50px;">
          </p>
        <?php endif; ?>

        <input type="hidden"
               name="tools[<?php echo e($i); ?>][_icon]"
               value="<?php echo e($tool['icon']); ?>">

        <input type="file"
               name="tools[<?php echo e($i); ?>][icon]"
               class="admin-form-control mb-1 <?php $__errorArgs = ['tools.'.$i.'.icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['tools.'.$i.'.icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="text"
               name="tools[<?php echo e($i); ?>][name]"
               placeholder="Tool name"
               value="<?php echo e($tool['name'] ?? ''); ?>"
               class="admin-form-control mb-1 <?php $__errorArgs = ['tools.'.$i.'.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['tools.'.$i.'.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button type="button"
                class="admin-btn admin-btn-danger remove-tool">
          Remove
        </button>
        <hr>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <button type="button"
          id="add-tool"
          class="admin-btn admin-btn-secondary">
    + Add Tool
  </button>
</div>
<?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/admin/courses/_form-fields.blade.php ENDPATH**/ ?>