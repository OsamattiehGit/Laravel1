document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('enroll-btn');
  if (!btn) return;

  // pull dynamic values from data-attributes
  const courseId    = btn.dataset.courseId;
  const courseTitle = btn.dataset.courseTitle;

  btn.addEventListener('click', () => {
    if (window.courseBalance <= 0) {
      return window.location.href = window.pricingUrl;
    }
    if (!confirm(`Enroll in “${courseTitle}”?`)) return;

    fetch(`${window.enrollUrlBase}/${courseId}/enroll`, {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
    })
    .then(r => r.ok ? r.json() : Promise.reject(r))
    .then(data => {
      alert(`${data.message}\nRemaining slots: ${data.balance}`);
      window.courseBalance = data.balance;
    })
    .catch(async err => {
      const e = err.json ? await err.json().catch(()=>{}) : null;
      alert(e?.error || 'Enrollment failed.');
    });
  });
});
