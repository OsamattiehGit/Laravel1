<thead>
  <tr>
    <th>Title</th>
    <th>Category</th>
    <th>Status</th>
    <th>Instructor</th>
    <th>Actions</th>
  </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($c->title); ?></td>
      <td><?php echo e($c->category->name ?? '—'); ?></td>
      <td><?php echo e(ucfirst($c->status)); ?></td>
      <td><?php echo e($c->instructor); ?></td>
      <td>
        <a href="<?php echo e(route('admin.courses.edit', $c)); ?>"
           class="admin-btn admin-btn-secondary"
        >Edit</a>

        <form
          action="<?php echo e(route('admin.courses.destroy', $c)); ?>"
          method="POST"
          style="display:inline-block;"
          onsubmit="return confirm('Delete this course?')"
        >
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button type="submit" class="admin-btn admin-btn-secondary">
            Delete
          </button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/admin/courses/_table.blade.php ENDPATH**/ ?>