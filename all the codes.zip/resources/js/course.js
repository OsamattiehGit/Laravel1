document.addEventListener("DOMContentLoaded", () => {
    const pathParts = window.location.pathname.split('/');
    const courseId = pathParts[pathParts.length - 1];

    fetch(`http://127.0.0.1:8000/api/courses/${courseId}`)
        .then(response => response.json())
        .then(data => {
            const course = data.data;

            document.body.innerHTML = `
                <h1>${course.title}</h1>
                <p>${course.description}</p>
                <p><strong>Instructor:</strong> ${course.instructor}</p>
                <p><strong>Enrollments:</strong> ${course.enrollments_count}</p>
            `;

            const enrollButton = document.createElement('button');
            enrollButton.textContent = "Enroll in this Course";
            enrollButton.style.marginTop = "20px";

            enrollButton.addEventListener("click", () => {
                fetch("http://127.0.0.1:8000/api/enrollments", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ course_id: course.id })
                })
                .then(res => res.json())
                .then(data => alert(data.message || "Enrolled!"))
                .catch(err => {
                    console.error("Error enrolling:", err);
                    alert("Something went wrong.");
                });
            });

            document.body.appendChild(enrollButton);
        })
        .catch(err => {
            console.error("Failed to fetch course:", err);
        });
});
