<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class EnrollmentController extends Controller
{
    public function store(Course $course)
{
    $user = auth()->user();
    if($user->course_balance <= 0) {
        return response()->json(['error'=>'no_balance'], 403);
    }

    $user->enrollments()->create(['course_id'=>$course->id]);

    return response()->json([
      'message' => "Enrolled in {$course->title}",
      'balance' => $user->course_balance
    ]);
}

}
