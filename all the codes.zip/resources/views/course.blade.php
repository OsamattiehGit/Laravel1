@extends('layouts.app')
@include('components.footer')

@vite(['resources/css/style.css', 'resources/js/course.js'])

@section('title', 'Course Details')

@section('content')
    <div class="container">
        <h1>Course Details</h1>
        <div id="course-details"></div>
    </div>
@endsection
