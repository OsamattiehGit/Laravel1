@extends('layouts.app')

@section('title', 'Courses List')

@push('styles')
<link rel="stylesheet" href="{{ asset('css/courses.css') }}">
@endpush

@push('scripts')
<script src="{{ asset('js/main.js') }}"></script>
@endpush

@section('content')
<div class="container py-4">

    <!-- Search + Filter -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <input type="text" class="form-control w-25" id="search-box" placeholder="Search for a course...">

   <div class="btn-group flex-wrap" role="group" aria-label="Filter Tabs">
    <button class="btn btn-outline-secondary filter-btn active" data-filter="all">All</button>
    <button class="btn btn-outline-primary filter-btn" data-filter="opened">Opened</button>
    <button class="btn btn-outline-warning filter-btn" data-filter="soon">Coming Soon</button>
    <button class="btn btn-outline-dark filter-btn" data-filter="archived">Archived</button>
</div>


        <select class="form-select w-25" id="sort-select">
            <option value="popular">Sort by Popular</option>
            <option value="newest">Newest</option>
            <option value="title">Title A-Z</option>
        </select>
    </div>

    <!-- Course Grid -->
    <div id="course-list" class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        {{-- JS will inject course cards here --}}
    </div>

    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-4" id="pagination">
        {{-- JS will inject pagination controls --}}
    </div>
</div>
@endsection
