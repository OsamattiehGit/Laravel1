
<!DOCTYPE html>
 <?php echo $__env->yieldPushContent('scripts'); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Ezyskills'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/css/pricing.css','resources/css/footer.css']); ?>
      <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
      <?php echo $__env->yieldContent('content'); ?>
    </main>
    
   <?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/main.js','resources/js/admin.js','resources/js/course.js','resources/js/home.js']); ?>

    
</body>
</html>
<?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>