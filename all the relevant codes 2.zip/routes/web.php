<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\AdminCourseController;
use App\Models\Course;

// 🔓 Public Pages
Route::view('/', 'home');
Route::get('/home', function () {
    $courses = Course::all();  // Fetch all courses
    return view('home', compact('courses'));
});
Route::view('/courses', 'courses')->name('courses');
Route::view('/faq', 'faq');
Route::view('/pricing', 'pricing');
Route::view('/contact', 'contact');
Route::view('/about', 'about');

Route::get('/course/{id}', [CourseController::class, 'show'])->name('course.show');
Route::get('/course/{course}/demo', [CourseController::class, 'demo'])->name('courses.demo');
Route::get('/course/{course}/enroll', [CourseController::class, 'enroll'])->name('courses.enroll');
Route::get('/course/{course}/download', [CourseController::class, 'download'])->name('courses.download');

// 🔒 Auth Routes (Breeze + Protected Routes)
Route::middleware('auth')->group(function () {
    Route::view('/dashboard', 'dashboard')->name('dashboard');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// ✅ CLEAN: Admin Course Routes (CRUD)
Route::middleware(['web', 'auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::resource('courses', AdminCourseController::class)->except('show');
        // This auto-defines:
        // admin.courses.index
        // admin.courses.create
        // admin.courses.store
        // admin.courses.edit
        // admin.courses.update
        // admin.courses.destroy
    });

require __DIR__.'/auth.php';
