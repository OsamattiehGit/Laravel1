document.addEventListener("DOMContentLoaded", function () {
    const API_URL = "http://127.0.0.1:8000/api/courses";
    const form = document.getElementById("course-form");
    const courseList = document.getElementById("course-list");
    const clearBtn = document.getElementById("clear-form");

    if (!form) return;

    form.addEventListener("submit", async e => {
        e.preventDefault();

        const id = document.getElementById("course-id").value;
        const objectives = document.getElementById('objectives')?.value.split(',').map(str => str.trim()).filter(Boolean) || [];
        const courseContent = document.getElementById('course_content')?.value.split(',').map(str => str.trim()).filter(Boolean) || [];

        const formData = new FormData();
        formData.append("title", document.getElementById('title')?.value || "");
        formData.append("description", document.getElementById('description')?.value || "");
        formData.append("instructor", document.getElementById('instructor')?.value || "");
        formData.append("category_id", document.getElementById('category_id')?.value || "");
        formData.append("user_id", 1);
        formData.append("status", document.getElementById('status').value);
        formData.append("objectives", JSON.stringify(objectives));
        formData.append("course_content", JSON.stringify(courseContent));

        const imageInput = document.getElementById("image");
        if (imageInput?.files?.length > 0) {
            formData.append("image", imageInput.files[0]);
        }

        const url = id ? `${API_URL}/${id}` : API_URL;
        const method = "POST";
        if (id) formData.append("_method", "PUT");

        try {
            await fetch(url, { method, body: formData });
            resetForm();
            loadCourses();
        } catch (err) {
            console.error("Save failed:", err);
            alert("Error saving course — check console.");
        }
    });

    function resetForm() {
        if (!form) return;
        form.reset();
        document.getElementById("course-id").value = "";
    }

    function loadCourses() {
        if (!courseList) return;
        courseList.innerHTML = "";
        fetch(API_URL)
            .then(res => res.json())
            .then(data => {
                data.data.forEach(course => {
                    const card = document.createElement("div");
                    card.className = "course-card";
                    let imageHTML = '';
                    if (course.image) {
                        imageHTML = `<img src="/${course.image}" style="max-height: 60px;" alt="Course Image"><br>`;
                    }
                    card.innerHTML = `
                        ${imageHTML}
                        <h3>${course.title}</h3>
                        <p>${course.description}</p>
                        <div class="details">
                            Instructor: ${course.instructor} | Enrollments: ${course.enrollments_count}
                        </div>
                        <p><strong>Objectives:</strong> ${course.objectives?.join(', ') || 'N/A'}</p>
                        <p><strong>Content:</strong> ${course.course_content?.join(', ') || 'N/A'}</p>
                        <button onclick="editCourse(${course.id})">Edit</button>
                        <button onclick="deleteCourse(${course.id})">Delete</button>
                    `;
                    courseList.appendChild(card);
                });
            });
    }

    function editCourse(id) {
        fetch(`${API_URL}/${id}`)
            .then(res => res.json())
            .then(data => {
                const c = data.data;
                document.getElementById("course-id").value = c.id;
                form.title.value = c.title;
                form.description.value = c.description;
                form.instructor.value = c.instructor;
                form.category_id.value = c.category_id;
                form.objectives.value = (c.objectives || []).join(', ');
                form.course_content.value = (c.course_content || []).join(', ');
                document.getElementById("status").value = c.status;
                window.scrollTo(0, 0);
            });
    }

    window.editCourse = editCourse;

    function deleteCourse(id) {
        if (!confirm("Delete this course?")) return;
        fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        })
        .then(() => loadCourses())
        .catch(err => console.error("Delete failed:", err));
    }

    window.deleteCourse = deleteCourse;

    if (clearBtn) {
        clearBtn.addEventListener("click", resetForm);
    }

    loadCourses();
});
