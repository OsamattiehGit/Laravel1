<footer style="text-align: center; padding: 20px; background-color: #0a2342; color: #fff;">
    <p>© 2025 EzySkills. All rights reserved.</p>
</footer>
