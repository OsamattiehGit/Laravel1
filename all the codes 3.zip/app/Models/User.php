<?php

namespace App\Models;
use App\Models\Enrollment;
use App\Models\Course;
// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',

    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
    // A user can create many courses
public function courses()
{
    return $this->hasMany(Course::class);
}

// A user can enroll in many courses
public function enrollments()
{
    return $this->hasMany(Enrollment::class);
}
public function subscriptions()
{
    return $this->hasMany(Subscription::class);
}
public function remainingEnrollments()
{
    $allowed = $this->subscriptions->sum('courses_allowed');
    $used = $this->enrollments->count();
    return $allowed - $used;
}
public function getTotalCourseLimitAttribute()
{
    return $this->subscriptions->sum('courses_allowed');
}

// slots used so far
public function getUsedCoursesCountAttribute()
{
    return $this->enrollments()->count();
}

// remaining slots
public function getCourseBalanceAttribute()
{
    return max(0, $this->total_course_limit - $this->used_courses_count);
}

}
