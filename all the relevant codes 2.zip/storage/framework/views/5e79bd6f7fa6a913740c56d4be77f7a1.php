<?php use Illuminate\Support\Str; ?>


<?php $__env->startSection('title', 'Home - Ezyskills'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(Vite::asset('resources/css/home.css')); ?>">

<section class="hero-section">
    <div class="hero-left">
        <h1 class="hero-heading">
            Skill Your Way <br>
            Up To Success <br>
            With Us
        </h1>
        <p class="hero-subheading">
            Get the skills you need for <br> the future of work.
        </p>

        <div class="search-bar">
            <input type="text" placeholder="Search the course you want">
            <button type="submit">Search</button>
        </div>

        <div class="tags">
            <span class="tag orange">Cloud Computing</span>
            <span class="tag gray">Cyber Security</span>
            <span class="tag gray">DevOps</span>
            <span class="tag gray">Data Science</span>
            <span class="tag gray">Software Testing</span>
        </div>
    </div>

    <div class="hero-right">
        <div class="layer-wrapper">
            <img src="<?php echo e(asset('images/small-circle-hero.svg')); ?>" alt="Hero Image" class="circle-hero-small">
<img src="<?php echo e(asset('images/hero-girl-circle.svg')); ?>" alt="Hero Image" class="circle-hero">
        <img src="<?php echo e(asset('images/hero-girl.svg')); ?>" alt="Hero Image" class="hero-img">
<div class="hero-right">



        <!-- Floating Course Cards -->
     <div class="floating-svg-card">
    <img src="<?php echo e(asset('images/icon-analyst.svg')); ?>" alt="Best Seller Course Cards">
</div>
</div>
</section>


<section class="ai-slider-section">
    <div class="container">
        <div class="ai-slider-content">
            <h2>
                <span class="highlight-blue">World’s</span><br />
                <span class="highlight-blue">First <span class="highlight-blue">AI Based</span></span><br />
                <span class="highlight-orange">Online Learning</span><br />
                <span class="highlight-orange">Platform</span>
            </h2>
        </div>

        <div class="ai-slider-carousel">
            <div class="carousel-track">
                <div class="carousel-slide active">
                    <img src="<?php echo e(asset('images/slide-course-selector.png')); ?>" alt="AI Based Course Selector">
                </div>
                <div class="carousel-slide">
                    <img src="<?php echo e(asset('images/slide-scenarios.png')); ?>" alt="AI Based Scenarios">
                </div>
                <div class="carousel-slide">
                    <img src="<?php echo e(asset('images/slide-quizzes.png')); ?>" alt="AI Based Quizzes">
                </div>
                <div class="carousel-slide">
                    <img src="<?php echo e(asset('images/slide-gamification.png')); ?>" alt="AI Based Gamification">
                </div>
            </div>

            <div class="carousel-dots">
                <span class="dot active"></span>
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </div>
    </div>
</section>


<section class="who-can-join">
    <div class="container">
        <div class="who-header">
            <span class="subheading-orange">WHO CAN JOIN</span>
            <h2>Skill Development<br>Schemes For All</h2>
        </div>
       <div class="who-content">
    <div class="who-left">
        <div class="who-header">
            <span class="subheading-orange">WHO CAN JOIN</span>
            <h2>Skill Development<br>Schemes For All</h2>
        </div>
        <div class="who-grid">
            <div class="who-item">
                <span class="who-number">01</span>
                <img src="<?php echo e(asset('images/icon-college.svg')); ?>" alt="College">
                <p>Colleges/Universities</p>
            </div>
            <div class="who-item">
                <span class="who-number">02</span>
                <img src="<?php echo e(asset('images/icon-working.svg')); ?>" alt="Professionals">
                <p>Individuals/Working Professionals</p>
            </div>
            <div class="who-item">
                <span class="who-number">03</span>
                <img src="<?php echo e(asset('images/icon-startup.svg')); ?>" alt="Startups">
                <p>Startups</p>
            </div>
            <div class="who-item">
                <span class="who-number">04</span>
                <img src="<?php echo e(asset('images/icon-corporate.svg')); ?>" alt="Corporates">
                <p>Corporates</p>
            </div>
        </div>
    </div>

    <div class="who-right">
        <img src="<?php echo e(asset('images/who-illustration.svg')); ?>" alt="Learning Illustration">
    </div>
</div>

    </div>
</section>

<section class="how-it-works">
    <div class="how-header">
        <span class="badge">How It Works</span>
    </div>
    <div class="how-content">
        <img src="<?php echo e(asset('images/how-it-works.svg')); ?>" alt="How It Works Steps">
    </div>
</section>



<!-- HOME.BLADE.PHP SECTION -->
<section class="popular-courses">
    <h2><span class="highlight-blue">Popular</span> <span class="highlight-orange">Courses</span></h2>

    <div class="course-grid">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="course-card">
            <div class="course-image">
                <img src="<?php echo e(asset('images/courses/' . strtolower(str_replace(' ', '-', $course->title)) . '.png')); ?>" alt="<?php echo e($course->title); ?>">
            </div>
            <div class="course-body">
                <h4><?php echo e($course->title); ?></h4>
                <p><?php echo e(Str::limit($course->description, 100)); ?></p>

                <div class="button-group">
                    <a href="<?php echo e(route('course.show', $course->id)); ?>" class="btn">Live Demo</a>
                    <a href="<?php echo e(route('course.show', $course->id)); ?>" class="btn btn-secondary">Enroll Now</a>
                </div>

                <a href="#" class="btn btn-full">Download Curriculum</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="view-all">
        <a href="<?php echo e(route('courses')); ?>" class="btn btn-view-all">View All Courses</a>
    </div>
</section>



<section class="achievements">
    <h3>Our Achievements</h3>
    <div class="stats">
        <div><strong>100</strong><p>Students Trained</p></div>
        <div><strong>50</strong><p>Courses Available</p></div>
        <div><strong>70%</strong><p>Got Level 1 Jobs</p></div>
    </div>
</section>

<section class="mentors">
    <h3>Meet Our Professional Mentors & Trainers</h3>
    <div class="mentor-list">
        <div><strong>Sandeep</strong><p>Expertise in AI, Cybersecurity, etc.</p></div>
        <div><strong>Sudhansu</strong><p>Expertise in AI, Cybersecurity, etc.</p></div>
        <div><strong>Ruchika Tuteja</strong><p>Expertise in AI, Cybersecurity, etc.</p></div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/home.blade.php ENDPATH**/ ?>