import './bootstrap';
import './ajax-utils';
import 'bootstrap';
import Alpine from 'alpinejs';
import * as bootstrap from 'bootstrap';

window.Alpine = Alpine;

Alpine.start();
