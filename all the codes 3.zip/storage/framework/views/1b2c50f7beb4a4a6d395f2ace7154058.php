<?php $__env->startSection('title', "Edit Course « {$course->title} »"); ?>

<?php $__env->startPush('styles'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin.css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="admin-container">

  <h1 class="admin-title">Edit Course « <?php echo e($course->title); ?> »</h1>

  <div class="admin-row">
    <div>
      <div class="admin-card">
        <div class="admin-card-header">Edit Course</div>
        <div class="admin-card-body">
          <form method="POST" action="<?php echo e(route('admin.courses.update', $course)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <?php echo $__env->make('admin.courses._form-fields', [
              'course'     => $course,
              'categories' => $categories,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="admin-form-group">
              <button type="submit" class="admin-btn admin-btn-primary">Update Course</button>
              <a href="<?php echo e(route('admin.courses.index')); ?>" class="admin-btn admin-btn-secondary">Cancel</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\LaravelProjects\ezyskills-backend\resources\views/admin/courses/edit.blade.php ENDPATH**/ ?>