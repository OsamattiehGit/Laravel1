<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\AdminCourseController;
use App\Http\Controllers\EnrollmentController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\ComplaintController;
use App\Models\Course;


// 🔓 Public Pages

Route::get('/', function () {
    $courses = Course::all();
    return view('home', compact('courses'));
})->name('home');

// Redirect /home to /
Route::get('/home', function () {
    return redirect()->route('home');
});
Route::view('/faq', 'faq');
Route::view('/contact', 'contact');
Route::view('/about', 'about');
Route::view('/courses', 'courses')->name('courses');
Route::view('/pricing', 'pricing')->name('pricing.page');

// Course detail pages - protected by auth
Route::middleware('auth')->group(function () {
    Route::get('/course/{course}', [CourseController::class, 'show'])->name('course.show');
    Route::get('/course/{course}/demo', [CourseController::class, 'demo'])->name('courses.demo');
    Route::get('/course/{course}/download', [CourseController::class, 'download'])->name('courses.download');
});

// 🔒 Auth-Protected Routes
Route::middleware('auth')->group(function () {
    Route::view('/dashboard', 'dashboard')->name('dashboard');

Route::get('/profile', [ProfileController::class, 'profile'])->name('profile');



 Route::post('/subscribe', [SubscriptionController::class, 'subscribe'])->name('subscribe');
});

// 🔐 Admin Panel
Route::middleware(['web', 'auth', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::resource('courses', AdminCourseController::class)->except('show');
    });
    Route::post(
  '/course/{course}/enroll',
  [EnrollmentController::class, 'enroll']
)->name('course.enroll')
 ->middleware('auth');
Route::post('/course/{course}/enroll', [EnrollmentController::class, 'enroll'])->name('course.enroll');
// Course selector page
Route::view('/course-selector', 'course-selector')->name('course.selector');

// Suggest a course placeholder (optional)
Route::get('/suggest-course', [CourseController::class, 'showSuggestionFlow'])->name('suggest.course');
Route::post('/suggest-course/result', [CourseController::class, 'getSuggestedCourses'])->name('suggest.course.result');


Route::get('/contact', [ComplaintController::class, 'showForm'])->name('contact.form');

Route::middleware('auth')->post('/contact', [ComplaintController::class, 'submit'])->name('contact.submit');

require __DIR__.'/auth.php';
