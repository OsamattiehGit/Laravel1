document.addEventListener("DOMContentLoaded", () => {
    loadCourses();
    document.getElementById("search-box").addEventListener("input", debounce(loadCourses, 300));
    document.querySelectorAll(".filter-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelector(".filter-btn.active")?.classList.remove("active");
            btn.classList.add("active");
            loadCourses();
        });
    });
    document.getElementById("sort-select").addEventListener("change", loadCourses);
});

function loadCourses(page = 1) {
    const query = document.getElementById("search-box")?.value.trim() || "";
    const filter = document.querySelector(".filter-btn.active")?.dataset.filter || "all";
    const sort = document.getElementById("sort-select")?.value || "";

    const url = `/api/courses?page=${page}&q=${query}&filter=${filter}&sort=${sort}`;

    fetch(url)
        .then(res => res.json())
        .then(data => {
            renderCourses(data.data);
            renderPagination(data.meta);
        });
}

function renderCourses(courses) {
    const container = document.getElementById("course-list");
    container.innerHTML = "";

    if (!courses.length) {
        container.innerHTML = '<p class="text-muted">No courses found.</p>';
        return;
    }

    courses.forEach(course => {
        const col = document.createElement("div");
        col.className = "col";

        const card = document.createElement("div");
        card.className = "course-card";

        card.innerHTML = `
            <img src="/${course.image || 'default-course.png'}" alt="${course.title}" class="img-fluid mb-2">
            <h5>${course.title}</h5>
            <p>${course.description.substring(0, 60)}...</p>
            <span class="badge bg-secondary">${course.category}</span>
            <div class="mt-2">
                <a href="/course/${course.id}" class="btn btn-outline-primary btn-sm">Details</a>
            </div>
        `;

        col.appendChild(card);
        container.appendChild(col);
    });
}

function renderPagination(meta) {
    const pagination = document.getElementById("pagination");
    pagination.innerHTML = "";
    if (meta.total <= meta.per_page) return;

    for (let i = 1; i <= meta.last_page; i++) {
        const btn = document.createElement("button");
        btn.className = "btn btn-sm mx-1 " + (i === meta.current_page ? 'btn-primary' : 'btn-outline-primary');
        btn.textContent = i;
        btn.addEventListener("click", () => loadCourses(i));
        pagination.appendChild(btn);
    }
}

function debounce(fn, delay) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => fn.apply(this, args), delay);
    };
}
