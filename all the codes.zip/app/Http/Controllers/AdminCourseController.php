<?php

namespace App\Http\Controllers;
use App\Models\Course;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminCourseController extends Controller
{
    public function index()
    {
        $courses = Course::all();
        $categories = Category::all();
        return view('admin.course-manager', compact('courses', 'categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'instructor' => 'required|string',
            'status' => 'required|in:opened,soon,archived',
            'image' => 'nullable|mimes:svg,png,jpg,jpeg|max:2048',
            'objectives' => 'nullable|string',
            'course_content' => 'nullable|string',
        ]);

        // Process objectives & course_content as JSON arrays
        $validated['objectives'] = json_encode(array_map('trim', explode(',', $request->objectives)));
        $validated['course_content'] = json_encode(array_map('trim', explode(',', $request->course_content)));
$validated['status'] = $request->status;

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('uploads/courses', $filename, 'public');
            $validated['image'] = 'storage/' . $path;
        }

        $validated['user_id'] = Auth::id() ?? 1;

        Course::create($validated);

       return redirect()->route('admin.courses')->with('success', 'Course added');
    }

    public function edit($id)
    {
        $course = Course::findOrFail($id);
        $categories = Category::all();
        return view('admin.courses.edit', compact('course', 'categories'));
    }

    public function update(Request $request, $id)
    {
        $course = Course::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'instructor' => 'required|string',
            'status' => 'required|in:opened,soon,archived',
            'image' => 'nullable|mimes:svg,png,jpg,jpeg|max:2048',
            'objectives' => 'nullable|string',
            'course_content' => 'nullable|string',
        ]);

        $validated['objectives'] = json_encode(array_map('trim', explode(',', $request->objectives)));
        $validated['course_content'] = json_encode(array_map('trim', explode(',', $request->course_content)));

        if ($request->hasFile('image')) {
            if ($course->image && file_exists(public_path($course->image))) {
                unlink(public_path($course->image));
            }

            $file = $request->file('image');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('uploads/courses', $filename, 'public');
            $validated['image'] = 'storage/' . $path;
        }

        $course->update($validated);

        return redirect()->route('admin.courses')->with('success', 'Course updated');
    }

    public function destroy($id)
    {
        $course = Course::findOrFail($id);

        if ($course->image && file_exists(public_path($course->image))) {
            unlink(public_path($course->image));
        }

        $course->delete();

        return redirect()->route('admin.courses')->with('success', 'Course deleted');
    }
}
