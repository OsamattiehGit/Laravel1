@extends('layouts.app')


@section('title', 'Contact Us')

@section('content')
<section style="max-width: 600px; margin: auto;">
    <h2>Contact Our Team</h2>
    <form method="POST" action="/api/contact">
        @csrf
        <label>Your name* <input name="name" required></label><br/>
        <label>Contact email* <input name="email" type="email" required></label><br/>
        <label>Message <textarea name="message" required></textarea></label><br/>
        <button type="submit">Send</button>
    </form>
</section>
@endsection
